
MAKEAVS.VBS
========================

This Script scans the folder it's run from 
every 60 seconds and creates .avs scripts
for any multipart ShowShifter AVI files.

You can then watch the entire recording
by playing the .avs file in showshifter.

Requires AVISynth version .3 to be installed

You should also use the Extensions registry 
key to tell showshifter that avs files are
video files.  See the showshifter website
for information on setting the Extensions 
registry key.

How To Use This Script:
=======================
Place it in your Write folder and double click
it.  
Your system must have VBScripting support
enabled for it to work.  Some anivirus software
disables vbscript, so if it doesn't work start 
there.

