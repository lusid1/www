PhotoViewer:
=================
by Sean Hatfield
sean@lusid.net


This is a Photo viewer module for Showshifter.  Unlike the standard photo module, this one allows you to browse folders of image files.  The interface uses a list based browser, not a thumbnail browser.  The standard transport controls and IR functions are supported.  It supports image rotation, pan & zoom, random play and repeat play.

Note: this module only supports folder browsing.  The "One Big List" mode is not supported.


Controls Mappings:
========================
Start Slideshow:   Play 
Pause Slideshow:   Pause
Stop Slideshow:    Stop
Next Picture:	   FF
Previoust Picture: Rewind
Rotate Right:  	   Channel Up
Rotate Left: 	   Channel Down
zoom in:	   ctrl -
zoom out:	   ctrl +

Additional controls in fullscreen mode:
=======================================
Zoom In:	   Enter
Zoom Out	   Escape
Pan Up:		   Up
Pan Down:	   Down
Pan Left:	   Left
Pan Right:	   Right


REQUIREMENTS:
=============
Showshifter 3.1 or later
GDI+ 
--GDI+ is included with WindowsXP or can be downloaded from Microsoft for vintage operating systems.

The english version can be downloaded here:
http://download.microsoft.com/download/platformsdk/redist/3097/W98NT42KMeXP/EN-US/gdiplus_dnld.exe
For other languages, search the Microsoft download center.

You may need to copy the dll into your showshifter folder.  

USAGE:
=============
This software is free for personal non-commercial use.  Redistribution is prohibited.  For commercial use, redistribution, or to include it in or with a commercial product, contact the author.



INSTALLATION:
=============
Copy the SCHPictureViewer.uis, SCHPictureViewerReadFolders.uis, and SCHPictureViewerSettings.uis files into your Showshifter\config folder. 

Copy the SCHPhotoViewer.dll file into your showshifter folder.

Copy the .bmp files into your config\buttons folder.

Register SCHPhotoViewer.dll by selecting "Register Server" from the context menu.  Alternatively, you can run RegAll in the Showshifter folder.


REMOVAL:
========
Unregister SCHPhotoViewer.dll by selecting "unregister server" from the context menu.  Then delete all the files listed above.


REGISTRY KEYS:
==============
This module stores some settings in the registry in this location:
HKEY_LOCAL_MACHINE\SOFTWARE\Home Media Networks\ShowShifter\Configuration\SCHPhotoModule\

ModuleName      - The Text that appears on the module's main menu button in showshifter
Directories     - The folders containing your image files
Extensions	- List of image file extensions
DisplayDuration - How long each image is shown in the slideshow
RandomPlay      - 1 = Random, 0 = Alphabetical
RepeatPlay      - 1 = Repeat Enabled, 0 = Repeat Disabled
UseIcons	- 1 = Use Shell Icons, 0 = Don't use shell icons
AutoMute	- 1 = Mute audio, 0 = Don't mute audio

The following keys are used to specify images for the main menu button.  The files must be located under config\menus.  By default, the images for the internal PictureViewer module will be used.

MenuItemEnabled
MenuItemFocussed
MenuItemPressed



HISTORY:
========
20050102
- Happy new year!
- Completely new interface for 3.10
- Info Panel shows slideshow status, and current photo info
- Slideshow stops when you change folders
- Slideshow stops when you exit the module
- Pan controls only visible in zoomed mode
- added support for standard zoom IRVKs
- Added tip text for all controls on the main page
- Improved remote control navigation in menu mode
- Several things I've forgotten about


20041020
- Significantly improved performance in thumbnail browser
- Thumbnail aspect ratio adjusts for 4x3 or 16x9 viewing modes based on your showshifter display settings
- Folders preview their contents in thumbnail mode
- lots of bug fixes


20040219
- Added thumbnail browser

20040212
- fixed compatability with Showshifter 3.01

20040123A
- fixed a (large) memory leak
- fixed rotate controls in fullscreen mode

20040123
- Added Zoom/Pan support
- Added keyboard controls for Rotate/Pan/Zoom functions
- Reduced dll size
- Fixed some bugs in the aspect ratio correction code

20040115
- Fixed compatability with ctrl+ navigational hotkeys
- Changed the default main menu icon to the Picture Viewer icon
- Added support for custom Main Menu Icons via the registry
- numerous internal code cleanups

20030817
- Added image rotation controls
  (might not work on win98)

20030815
- Fixed Win2K compatability
- Minor skin edits
- Added a registry key to disable Shell Icons

20030811
- Initial Release

