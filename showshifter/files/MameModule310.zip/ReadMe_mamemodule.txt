MAME Module:
============
by Sean Hatfield

This is a MAME front end module for Showshifter.  It lets you pick a supported game from a list and launch that game in MAME.  It currently supports PNG formatted screenshots, such as those available from the mame32QA site. 

USAGE NOTES:
============
Before you can run mame, go to the MAME options page, and specify the location of your mame.exe and your snapshot folder (usually mame\snap).  
Then refresh the game list and it will build your game database.

To use your snapshots, extract your PNG formatted snapshots into your mame\snap folder.  Zipped snapshot archives are not supported.

If there is no snapshot available for a game, it will try to use the snapshot for the parent game.  

Mame snapshots for all supported games are available at the mame32qa site.  Currently it can be found at http://www.classicgaming.com/mame32qa

You can also create your own snapshots by pressing f12 during a game, and if you want to replace the existing snapshot you can delete the old one first on the game settings page.


GAME LIST FILES
===============
The gamelists are stored in your mame folder as text files. 
It currently uses ssavailable.txt, ssclones.txt and ssmame.txt.
If you install a new mame version, or add additional roms, use the Search for New games button on the MAME settings page to rebuild the game lists.  Then refresh the list on the main page.


REQUIREMENTS:
=============
MAME (win32 console version)
Showshifter 3.10 or later(of course)
GDI+ (for PNG Snapshot support).
--GDI+ is included with WindowsXP or can be downloaded from Microsoft for vintage operating systems.

The english version can be downloaded here:
http://download.microsoft.com/download/platformsdk/redist/3097/W98NT42KMeXP/EN-US/gdiplus_dnld.exe
For other languages, search the Microsoft download center.

You may need to copy the dll into your showshifter folder.  


INSTALLATION:
=============
Copy the MameModule.uis, MameGameSettings.uis, and MameSettings.uis files into your Showshifter\config folder. 
note: there are standard and overscan versions included.  Use the overscan versions if your use tv-out with overscan enabled.

Copy the MameModule.dll file into your showshifter folder.
Copy the MameModuleEnable.bat and MameModuleDisable.bat files into your Showshifter folder.
Copy MAMEMenuItemEnabled.bmp, MAMEMenuItemFocussed.bmp, and MAMEMenuItemPressed.bmp into Showshifter\Config\Menus.
Note: There are alternate bitmaps for use with the blue and green skins included in the zip.  If you are using the retroskin, leave out these bitmaps.

Double click MameModuleEnable.bat



REMOVAL:
========
Double click MameModuleDisable.bat then delete all the files listed above.


REGISTRY KEYS:
==============
This module stores some settings in the registry in this location:
HKEY_LOCAL_MACHINE\SOFTWARE\Home Media Networks\ShowShifter\Configuration\MameModule\

ModuleName - The Text that appears on the module's main menu button in showshifter
PlayerEXE  - The path to the mame.exe
Snap       - The path to the screenshots folder
HideClones - 1 = Hide Clones, 0 = Show Clones
HideMissing  1 = Hide Missing games, 0 = Show Missing games (Missing means mame can't find your game rom)

HKEY_LOCAL_MACHINE\SOFTWARE\Home Media Networks\ShowShifter\Configuration\MameModule\Options\

Parameters - The command line parameters to pass to the mame.exe.  

There will also be a subfolder created under options for each game that is run.  This is where game specific settings are stored.  Each folder currently has two keys:

UseDefaults - 1 = use the Parameters specified above.
            - 0 = use the Parameters specified below:

Parameters  - The command line parameters to pass to the mame.exe for this specific game, if UseDefaults is set to 0.

There are numerous additional keys to support the various game options.  Most of them are 1 for enable, 0 for disable.


HISTORY:
========
20041026
-Fixed dll compatability with SHowshifter 3.10
--Note: This version is no longer compatable with older versions of Showshifter.
-Fixed compatability with DVB & PVR tuner cards

20040214
-Fixed dll compatability with 3.01
-Fixed game settings skin for 3.x uis parser

20030926
-Added code to load custom buttons on the main menu

20030717
-Bugfix: Crash launching mame if you haven't opened the Default Settings page before
-Removed: Refresh list button.  The list now refreshes itself whenever you leave the MAME Options screen.

20030709
-Added: Delete Snapshot button on the Game Settings page.
-Added: Search for new games button on the MAME Settings page
-Fixed: Gamelist creation on win9x machines

20030708
Fixed a minor navigation issue in the skin files.








