VDubSSF 

When a ShowShifter AVI or SSF file is opened with this script, it loads the file and all of it's parts into virtual dub.  It will also load a set of video filters if you save you processor settins to a vcf file and specify the filename in this script.  It will also start a frameserver automatically.

To install:
Copy the script to your system, and edit the configuration section at the top of the file.

You need to specify the location of your VirtualDub.EXE file, your VCF file containing your standard video filters, and the output folder for the frameserver placeholder file.


To Use: 
Open the first showshifter avi for ssf file with this script.  Either by drag&drop, open with, or at a command line.  

