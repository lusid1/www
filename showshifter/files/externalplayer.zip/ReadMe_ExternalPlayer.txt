External Player Module:
=======================
by Sean Hatfield

This is an external player module for Showshifter.  It lets you open a video file from Showshifter's video read folders, and play it in the application of your choice.  It also automatically mutes the line in, and enforces that mute setting while it is active.

For this to work, you need a pretty powerful CPU to allow showshifter to record and another app to play simultaneously. How powerful will depend on what video size and compression formats you are using, and what deinterlace filters you are using.  


USES:
============
:Simultaneous Play and Record:  
While showshifter is recording, or live tv is paused,  use this module to open a video in an external media player.  The file browser is designed after the PVR module's file browser, and the module keeps the live-tv muted for you.  

:Chasing Playback: 
Also with this module, you can timeshift a recording in progress (chasing playback).  Just start a recording using an .ssf based compression setting, then open that recording in progress with the External Player module.  

:Video Jukebox: 
If your external player supports enqueue, you can alt-tab back to showshifter to send additional videos into the player's queue.  

:Mute Enforcement: 
As long as this module is active, the live-tv will stay muted.  This allows you to listen to music or watch a dvd in another app without the TV-Audio imposing itself everytime a timed recording starts or stops in showshifter.



INSTALLATION:
=============
Copy the ExternalPlayer.uis file into your Showshifter\config folder.
Copy the ExternalPlayer.dll file into your showshifter folder.
Copy the ExternalPlayer.html file into your Showshifter\Docs\Help folder.
Register the ExternalPlayer.dll by either rightclicking and selecting Register Server or by running RegAll.exe in the showshifter folder.

An overscan version of the .uis file is also included in the zip.


REMOVAL:
========
Unregister the ExternalPlayer.dll by right-clicking it and selecting Unregister Server.
Delete the ExternalPlayer.dll and ExternalPlayer.uis file.
Delete ExternalPlayer.html.


REGISTRY KEYS:
==============
This module stores some settings in the registry in this location:
HKEY_LOCAL_MACHINE\SOFTWARE\Home Media Networks\ShowShifter\Configuration\ExternalPlayer\

ModuleName - The Text that appears on the module's main menu button in showshifter



EXTERNAL PLAYERS:
=================
I have tested this module with Window Media Player, and Zoom Player.  I prefer Zoom Player, since it can be configured for near seemless integration.  


What's New:
============
20040213
-Fixed compatability with Showshifter V3.01

20030715
-The file picker now remembers the last folder you opened something from

20030623
-Mute is now enforced while you are in the External Player module
-Soundcard and TV audio line settings are read from Showshifter's registry keys
-Added smarter Mute related logic
-Added a registry key to change to module's name
-File list now refreshes when you exit and enter the External Player Module
-Removed some debug code that was popping up after using the file picker
-Fixed a couple bugs in the file search routines
-Fixed a few minor issues with the skin

20030621
-Auto-mute now saves and restored the affected mixer lines
   so now it works with the TV in pause mode.

20030620
-Added Auto-mute features
-Added IR control support (mute & play)
-Removed the Mute button, for consitency with the rest of SS.
-Added a mute indicator.  While in the external player module this
  indicates the mute status of the line-in. 
-Fix list focus when browsing
-numerous little bugfixes


20030619:
-Bugfix: Several memory leaks have been plugged
-Added the Up Icon to ".." folders.
-Added the shell icons to the rest of the folders and files
-Lots of cleanup in the source

20030617:
-BugFix: List not cleared before rescan
-BugFix: Ignored Folders with "All Drives" enabled
-BugFix: Duplicate entries when VideoFolders overlap
-Added folder mode
-Added folder mode toggle button
-Changed list caption to show current location
-Mute is enabled when you play a file
-Mute is disabled when you leave the External Player page
-Added overscan skin

20030614:	
-Cleaned up the video list
-Sorted the video list alphabetically
-kludged the filepicker to work with the new list





