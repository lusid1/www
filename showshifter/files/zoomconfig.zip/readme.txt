This file contains my Zoom Player settings, intended for use with ZoomPlayer 3.x, Showshifter 2.x, and the External Player module.  They configure zoom player to open full screen, use showshifter's keymappings, etc.  

Extract both files into your zoom player folder, and double click Showshifter.reg to import the settings.  If you installed zoom playere into the default location (C:\Program Files\Zoom Player) then the key configuration should be automatically setup as well.  Otherwise set Showshifter.key as a custom key file in zoom player's key options screen.

I have set up the keyfile to use Pause, Stop, FF, RW, Cycle Aspect Ratio, using Showshifter's key mappings.  This should be enough to get you up and running.  If you need to map other keys, please read the Zoom Player documentation.

As of Showshifter version 2.10, Zoom player doesn't seem to be able to open .ssf files on it's own so I created a manual graph file as a workaround.  To use it, place ssf.mediagraph in Zoom Player's MediaGraph folder.  Then enable it in zoom player as follows: in the Player Options screen, go to the Filter Control panel, then select Auto by Extension on the Management tab.


-Sean
(Lusid)


