This zip includes Overscan versions of the blue skin, as well as both regular and overscan versions on the modified timerevent.uis file.

To install the overscan skin:

1.  Run Skins.exe and install the blue skin

2.  Extract this archive into the Showshifter\skins folder.


This will replace the .uis files from the skin pack with the Overscan enabled versions.  To revert to the regular version, simply reinstall the skin pack with skins.exe.


To use the modified timerevent.uis, replace the timerevent.uis file with either the normal or overscan version from the zip file.

