ShowSaver Readme
================

ShowSaver is a VBScript designed to save showshifted files before ShowShifter deletes them.   

It has two modes of operation.  In regular mode, you must run the script while you are showshifting, before you push stop.  It will wait for you to finish showshifting, then save the files from destruction.  In Recursive mode, the script always runs in the background.  It will save every showshifting session.  


Requirements/Limitations:
=========================
-It will not work on Windows9x or ME.
-It can only monitor 1 video folder.
-The saved files report an incorrect duration in the file player

Installation
============
1. Copy the script to any location on your hard drive.
2. Edit the script in notepad to specify your video folder, and the recursive mode setting.
3. Make a shortcut to the script in some easily accessible place.


NOTES:
======
If you are running the script in recursive mode, it will run until you either restart or kill the wscript process.  Be careful not to launch multiple instances.

This script was hacked together as a stopgap until ShowShifter natively supports saving showshifted files.  

Use this script at your own risk.

