These scripts automate the ss avi to vcd conversion process.

The burning scripts need some cleanup, so I'll post them later.  Getting the conversion scripts working should keep you busy until then.



Enable capture logging in showshifter

Set your recording format to SS AVI

Save your virtualdub settings to an vcf file

save your tmpgenc settings to an mcf file

Disable the project wizard in tmpgenc.

Extract the contents to a folder.

Configure the options in the settings.ini

run scan.vbs

record something

cross fingers.

Stop recording.

It may take a minute or two to start converting.  Once it starts you can bring showshifter to the foreground, but don't minimize the other apps or they won't close down properly when they finish.  If it doesn't work or stalls at some point it's probably the interaction between vdubs frameserver and tmpgenc isn't working.  It uses a .avi placeholder for the frameserver so walk through the process by hand first to make sure all the apps are setup and working together.

Scan.vbs can use the beginning of the filename to customise the convertion on a show by show basis.  Just follow the examples in the file.  It calls the MakeMPG function, which takes these options:

MakeMPG VideoFile, VCF, MCF, "Burn", Delete

VideoFile is set internally and should not be changed

VCF is the virtualdub settings file to use on that show.  DefaultVCF comes from the settings.ini, but others can be defined in scan.vbs as needed.

MCF is the tmpgenc setting file to use on that show.  DefaultMCF comes from the settings.ini, but others can be defined in scan.vbs as needed.

"Burn" has 2 options, "Burn" or "NoBurn".  If set to "Burn" it will launch the VCDBurn script defined in settings.ini.  For now, set it to "NoBurn".

Delete: -1 = Never, 0 = Always, xxx = Delete if mpeg is larger than xxx Megs.  Set it to -1 until you are confident everything is working reliably.  Set it to DefaultDel to take the setting from the settings.ini file.

The default looks like this:
	MakeMPG VideoFile, DefaultVCF, DefaultMCF, DefaultBurn, DefaultDel



Good luck.  It's been running flawlessly for me for months, so you'll probably never get it to work =)






