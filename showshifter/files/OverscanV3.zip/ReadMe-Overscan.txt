Here's the new overscan skin for Showshifter version 3.


Installation:
=============
1. Exit Showshifter.

2. Extract the zip file into your Showshifter folder.  
	The .uis files should land in showshifter\config 
	and the Overscan.jpg should land in showshifter\config\Backgrounds.

3. Run the OverscanOn.reg file to enable the overscan skin.

To return to the default skin, run OverscanOff.reg

Note: The skins in showshifter may be version dependent.  If you experience repeatable crashes with the overscan skin enabled, try disabling the overscan skin before contacting Showshifter for support.  If the skin seems to be causing crashes, find me in the SS Forum and let me know about it.


